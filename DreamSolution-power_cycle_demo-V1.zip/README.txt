﻿EN25-Absolute 전원 OFF→ON 각도 유지 확인 - 파이썬 예제 (드림솔루션)

[준비물]
- 앱솔루트 로터리엔코더 EN25-Absolute
- USB TO RS232/TTL 컨버터 모듈
- PC
  (모든 준비물은 아래 상품 정보 링크주소에서 구매가능)
- 배선: 빨강 → 5V, 초록 → GND, 흰색(RS232) → USB TO RS232/TTL 컨버터 모듈의 RX  (통신속도 38400bps)

[웹페이지로 실행 (설치 필요 없음)]
- DreamSolution-power_cycle_demo_web-V1.html 을 Chrome 또는 Edge 로 엽니다.
- '엔코더 연결' → COM 포트 선택 → 전원을 껐다 켜보세요.
- 엔코더 없이 보려면 '시뮬레이션' 체크 또는 체험 모드 사용.

[파이썬으로 실행]
1. Python 3 를 설치합니다.  https://www.python.org
2. 명령 프롬프트에서 필요한 패키지를 설치합니다.
       pip install pyserial
3. power_cycle_demo.py 를 IDLE 로 열고, 파일 위쪽의 PORT 값을
   엔코더가 연결된 포트(예: "COM5")로 바꿉니다.
   (장치 관리자 > 포트(COM & LPT) 에서 확인)
4. F5 (Run Module) 를 누릅니다.
5. 전원을 끄고(빨간선 분리 또는 USB 뽑기), 샤프트를 돌린 뒤, 다시 켜보세요.
   켜자마자 현재 각도와 꺼진 동안 돌아간 양이 표시되고,
   결과가 power_cycle_log.csv 에 저장됩니다.

[상품 정보]
https://www.dreamparts.co.kr/goods/goods_view.php?goodsNo=1000000042
