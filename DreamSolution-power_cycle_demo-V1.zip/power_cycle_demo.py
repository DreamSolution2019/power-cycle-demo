# -*- coding: utf-8 -*-
"""
EN25-Absolute 전원을 껐다 켜도 각도를 기억하는지 확인하는 예제
------------------------------------------------------------------
- 엔코더 출력: 38400bps, 100Hz,  "$ANG,152.3,11.644,110\r\n"
                                   (절대각도[deg], 누적회전수[rev], RPM)
- 엔코더 데이터가 OFF_TIMEOUT 초 이상 끊기면 '전원 OFF' 로 판단하고,
  끊기기 직전 각도를 기억합니다.
- 전원이 꺼진 동안 샤프트를 돌린 뒤 다시 켜면,
  켜자마자 들어온 각도와 꺼지기 직전 각도를 비교해서 보여줍니다.
- "일반 인크리멘탈 엔코더였다면" 전원을 켠 위치가 0° 가 되므로
  그 값(가상)도 함께 보여줍니다.
- 전원을 껐다 켤 때마다 결과를 power_cycle_log.csv 에 저장합니다.
  (돌리지 않고 껐다 켜면 '자체 시험' 기록으로 쓸 수 있어요)

전원 끄는 방법 (둘 중 편한 것):
    1) 빨간선(5V)에 스위치를 달거나 커넥터를 뺐다 끼우기
    2) USB TO RS232/TTL 컨버터의 USB 를 뽑았다 꽂기 (자동으로 다시 연결)

필요 패키지:
    pip install pyserial

실행 방법:
    1) IDLE 에서 이 파일을 열고 F5 (Run Module)  ← 아래 PORT 값만 맞추면 됨
    2) 명령창:  python power_cycle_demo.py --port COM5
"""

import argparse
import csv
import os
import sys
import time

import serial
import serial.tools.list_ports

# ======== 여기만 바꾸세요 ========
PORT = "COM5"          # 엔코더가 연결된 포트 (장치관리자 > 포트(COM & LPT) 에서 확인)
OFF_TIMEOUT = 0.3      # 데이터가 이 시간(초) 이상 끊기면 '전원 OFF' 로 판단
STILL_LIMIT = 1.0      # 꺼진 동안 회전량이 이 각도 미만이면 '제자리(돌리지 않음)' 로 봄
# ================================

BAUDRATE = 38400
ON_SAMPLES = 5         # 전원을 켠 직후 각도: 처음 5개(약 0.05초) 평균
OFF_SAMPLES = 10       # 꺼지기 직전 각도: 마지막 10개(약 0.1초) 평균
IN_IDLE = "idlelib" in sys.modules  # IDLE 은 \r 한 줄 갱신을 지원하지 않음
LOG_CSV = os.path.join(os.path.dirname(os.path.abspath(__file__)), "power_cycle_log.csv")


# ---------------- 엔코더 읽기 ----------------
def parse_line(line):
    """'$ANG,152.3,11.644,110' -> (152.3, 11.644, 110.0), 실패 시 None"""
    if not line.startswith("$ANG"):
        return None
    parts = line.split(",")
    if len(parts) < 4:
        return None
    try:
        return float(parts[1]), float(parts[2]), float(parts[3])
    except ValueError:
        return None


def angle_diff(a, b):
    """a-b 를 -180~+180 범위로 (359.9° -> 0° 넘어갈 때 대비)"""
    return (a - b + 180.0) % 360.0 - 180.0


def average_angle(values):
    """0/360 경계 근처에서도 올바르게 평균내기 위해 첫 값 기준 차이로 평균"""
    ref = values[0]
    avg = ref + sum(angle_diff(v, ref) for v in values) / len(values)
    return avg % 360.0


def fmt(deg):
    """359.97 -> '0.0', -0.04 -> '0.0'"""
    v = round(deg, 1) % 360.0
    return f"{0.0 if abs(v) < 0.05 else v:.1f}"


# ---------------- 전원 OFF/ON 판단 ----------------
class PowerCycleTracker:
    """엔코더 각도가 들어올 때마다 feed(), 주기적으로 tick() 을 부른다.
    두 함수 모두 일어난 일을 (종류, 내용) 목록으로 돌려준다."""

    def __init__(self, off_timeout=OFF_TIMEOUT):
        self.off_timeout = off_timeout
        self.powered = None          # None: 아직 데이터 없음, True: ON, False: OFF
        self.last_data_at = 0.0
        self.recent = []             # 최근 각도 (꺼지기 직전 각도 계산용)
        self.on_buf = []             # 켜진 직후 각도 모으는 곳
        self.off_angle = None        # 꺼지기 직전 각도
        self.off_at = 0.0
        self.cycle = 0
        self.inc_total = 0.0         # 가상 인크리멘탈: 전원을 켠 뒤 돌아간 양 (누적)
        self.inc_last = None
        self.deg = None
        self.rev = 0.0

    @property
    def incremental(self):
        """가상 인크리멘탈 엔코더 값 (켠 위치 = 0°, 0~359.9° 로 환산)"""
        return self.inc_total % 360.0

    def feed(self, deg, rev, now):
        events = []
        self.last_data_at = now
        self.deg, self.rev = deg, rev

        if self.powered is None:                     # 프로그램 시작 후 첫 데이터
            self.powered = True
            self._reset_incremental(deg)
            events.append(("start", deg))
        elif self.powered is False:                  # 꺼져 있다가 데이터가 다시 들어옴
            self.on_buf.append(deg)
            if len(self.on_buf) < ON_SAMPLES:
                return events
            on_angle = average_angle(self.on_buf)
            self.on_buf = []
            self.powered = True
            self.cycle += 1
            self._reset_incremental(on_angle)
            events.append(("on", {
                "cycle": self.cycle,
                "off_at": self.off_at,
                "on_at": now,
                "off_sec": now - self.off_at,
                "off_angle": self.off_angle,
                "on_angle": on_angle,
                "rotated": angle_diff(on_angle, self.off_angle),
                "rev": rev,
            }))

        # 가상 인크리멘탈: 켠 뒤로 돌아간 양을 계속 더함
        self.inc_total += angle_diff(deg, self.inc_last)
        self.inc_last = deg

        self.recent.append(deg)
        if len(self.recent) > OFF_SAMPLES:
            self.recent.pop(0)
        return events

    def tick(self, now):
        if self.powered and now - self.last_data_at > self.off_timeout:
            self.powered = False
            self.off_angle = average_angle(self.recent)
            self.off_at = self.last_data_at
            self.recent = []
            self.on_buf = []
            return [("off", self.off_angle)]
        return []

    def _reset_incremental(self, deg):
        self.inc_total = 0.0
        self.inc_last = deg


# ---------------- CSV 기록 ----------------
CSV_HEADER = ["회차", "전원 OFF 시각", "전원 ON 시각", "꺼져 있던 시간(초)",
              "OFF 직전 각도(°)", "ON 직후 각도(°)", "꺼진 동안 회전(°)",
              "판정", "인크리멘탈(가상) ON 값(°)"]


def save_csv(r):
    new = not os.path.exists(LOG_CSV)
    stamp = lambda t: time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(t))
    judge = "제자리" if abs(r["rotated"]) < STILL_LIMIT else "회전함"
    try:
        # utf-8-sig: 엑셀에서 열어도 한글이 깨지지 않음
        with open(LOG_CSV, "a", newline="", encoding="utf-8-sig" if new else "utf-8") as f:
            w = csv.writer(f)
            if new:
                w.writerow(CSV_HEADER)
            w.writerow([r["cycle"], stamp(r["off_at"]), stamp(r["on_at"]), f"{r['off_sec']:.1f}",
                        fmt(r["off_angle"]), fmt(r["on_angle"]), f"{r['rotated']:+.1f}",
                        judge, "0.0"])
    except PermissionError:
        print(f"   (CSV 저장 실패: {os.path.basename(LOG_CSV)} 파일이 엑셀에 열려 있으면 닫아주세요)")


# ---------------- 화면 출력 ----------------
def show_result(r, still):
    print("\n")
    print("=" * 58)
    print(f" [{r['cycle']}회차] 전원 ON!  ({r['off_sec']:.1f}초 동안 꺼져 있었어요)")
    print("-" * 58)
    print(f"  꺼지기 직전 각도        : {fmt(r['off_angle']):>6}°")
    print(f"  ○ EN25-Absolute (실제)  : {fmt(r['on_angle']):>6}°   ← 켜자마자 현재 각도")
    print(f"  ✕ 인크리멘탈 (가상)     : {'0.0':>6}°   ← 0 부터 다시 셈 (원점 복귀 필요)")
    print("-" * 58)
    if abs(r["rotated"]) < STILL_LIMIT:
        print(f"  돌리지 않고 껐다 켬 → 차이 {r['rotated']:+.1f}°  (같은 각도 유지)")
    else:
        print(f"  꺼진 동안 {r['rotated']:+.1f}° 돌아간 것까지 알아냈어요!")
    print(f"  누적 회전수는 전원을 켤 때 초기화돼요 (지금 {r['rev']:.3f} rev)")
    if still:
        diffs = [abs(d) for d in still]
        print(f"  [자체 시험] 제자리 재투입 {len(still)}회, 최대 차이 {max(diffs):.1f}°")
    print("=" * 58)
    print(f"  기록 저장: {os.path.basename(LOG_CSV)}\n")


def show_live(tr):
    text = (f"전원 ON  EN25 각도 {fmt(tr.deg):>6}°  |  "
            f"인크리멘탈(가상) {fmt(tr.incremental):>6}°  |  누적 {tr.rev:9.3f} rev")
    if IN_IDLE:
        print(text)
    else:
        print("\r" + text + "   ", end="", flush=True)


# ---------------- 메인 ----------------
def open_port(name):
    # timeout 을 짧게: 데이터가 끊긴 것을 0.3초 안에 알아채야 하므로
    return serial.Serial(name, BAUDRATE, timeout=0.05)


def main():
    p = argparse.ArgumentParser(description="EN25-Absolute 전원 OFF→ON 각도 유지 확인")
    p.add_argument("--port", default=PORT, help="시리얼 포트 (예: COM5)")
    p.add_argument("--timeout", type=float, default=OFF_TIMEOUT,
                   help="데이터가 이 시간(초) 이상 끊기면 전원 OFF 로 판단")
    args = p.parse_args()

    try:
        ser = open_port(args.port)
    except serial.SerialException as e:
        print(f"{args.port} 포트를 열 수 없어요: {e}\n")
        print("사용 가능한 포트:")
        for port in serial.tools.list_ports.comports():
            print(f"  {port.device}  -  {port.description}")
        print("\n파일 위쪽의 PORT 값을 엔코더 포트로 바꿔주세요.")
        print("(다른 프로그램이 이 포트를 쓰고 있으면 먼저 닫아주세요.)")
        return

    print("EN25-Absolute 전원 OFF→ON 각도 유지 확인 (종료: Ctrl+C)")
    print("1) 샤프트를 아무 각도로 돌려 두고   2) 전원을 끈 뒤 다른 각도로 돌리고   3) 다시 켜보세요.")
    print("   전원 끄기: 빨간선(5V) 분리 또는 USB 뽑기\n")

    tr = PowerCycleTracker(args.timeout)
    still = []                       # 제자리 재투입 때의 차이 (자체 시험)
    buf = b""
    last_print = 0.0
    start = time.time()
    warned = False

    while True:
        # ---- 데이터 읽기 (USB 가 빠지면 다시 꽂힐 때까지 기다림) ----
        try:
            chunk = ser.read(ser.in_waiting or 1)
        except serial.SerialException:
            ser.close()
            for kind, val in tr.tick(time.time() + 999):    # USB 분리 = 바로 전원 OFF
                print(f"\n\n🔌 USB 연결이 끊어졌어요 → 전원 OFF 로 처리 (마지막 각도 {fmt(val)}°)")
            print("   USB 를 다시 꽂으면 자동으로 이어서 측정해요...")
            while True:
                time.sleep(0.5)
                try:
                    ser = open_port(args.port)
                    buf = b""
                    print("   USB 다시 연결됨!")
                    break
                except serial.SerialException:
                    pass
            continue

        buf += chunk
        now = time.time()
        while b"\n" in buf:          # 한 줄씩 잘라서 처리
            line, buf = buf.split(b"\n", 1)
            data = parse_line(line.decode("ascii", errors="ignore").strip())
            if not data:
                continue
            for kind, val in tr.feed(data[0], data[1], now):
                if kind == "start":
                    print(f"측정 시작: 현재 각도 {fmt(val)}°\n")
                elif kind == "on":
                    if abs(val["rotated"]) < STILL_LIMIT:
                        still.append(val["rotated"])
                    show_result(val, still)
                    save_csv(val)

        # ---- 전원 OFF 판단 ----
        for kind, val in tr.tick(now):
            print(f"\n\n⏻ 전원 OFF 감지!  꺼지기 직전 각도 {fmt(val)}°")
            print("   지금 샤프트를 다른 각도로 돌린 뒤 전원을 다시 켜보세요...")

        if tr.powered is None and not warned and now - start > 3:
            warned = True
            print("⚠ 3초 동안 엔코더 데이터($ANG,...)가 들어오지 않았어요.")
            print("   - 전원(빨강 5V/초록 GND) 또는 흰색(RS232) 선이")
            print("     USB TO RS232/TTL 컨버터 RX 에 연결됐는지 확인하세요.")
            print("   - 다른 프로그램이 이 포트를 쓰고 있으면 닫아주세요.\n")

        # ---- 현재 값 표시 (명령창: 0.2초마다 한 줄 갱신 / IDLE: 1초마다 새 줄) ----
        interval = 1.0 if IN_IDLE else 0.2
        if tr.powered and now - last_print >= interval:
            last_print = now
            show_live(tr)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n종료합니다.")
